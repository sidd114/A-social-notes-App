from django.apps import AppConfig


class SocialappConfig(AppConfig):
    name = 'socialapp'
