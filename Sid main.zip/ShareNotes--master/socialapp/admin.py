from django.contrib import admin
from .models import reg,notes,shared
# Register your models here.
admin.site.register(reg)
admin.site.register(notes)
admin.site.register(shared)
